export type StoryItem = {
  id: number;
  category: string[];
  title: string;
  img: string;
};